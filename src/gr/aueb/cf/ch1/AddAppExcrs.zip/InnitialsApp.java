package gr.aueb.cf.ch1;


/**
 * Εκτυπώνει τα αρχικά με *
 */
public class InnitialsApp {
    public static void main(String[] args) {

        //Εκτύπωση Εντολών
        System.out.println("    *    *       *");
        System.out.println("    * *  *      * *");
        System.out.println("    *  * *     * * *");
        System.out.println("    *    *    *     *");

    }
}
