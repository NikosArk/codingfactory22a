package gr.aueb.cf.ch1;


/**Να προσθέτει και να εκτυπώνει το
 * άθροισμα δύο ακεραίων
 */

public class AddAppExcrs {
    public static void main(String[] args) {

        //Δήλωση μεταβλητών
        int num1 = 19;
        int num2 = 30;
        int sum = 0;

        //Εντολές
        sum = num1 + num2;

        //Εκτύπωση αποτελεσμάτων
        System.out.println("Το αποτελέμσα της πρόσθεσης είναι ίσο με " + sum);

    }
}
